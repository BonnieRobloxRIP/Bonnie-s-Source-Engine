execute as @a[tag=!lobby, tag=!easy, tag=!medium, tag=!hard, tag=!extreme, tag=!training, tag=!endless] at @s run tp @s 0 86 -16
execute as @a[tag=!lobby, tag=!easy, tag=!medium, tag=!hard, tag=!extreme, tag=!training, tag=!endless] at @s run scoreboard players reset @s music
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s add lobby
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0, tag=!host] at @s run gamemode a @s
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run scoreboard players reset @s music
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove spectator
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove easy
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove easy_music
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove easytunnel1
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove easytunnel2
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove easytunnel3
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove easytunnel4
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove easytunnel5
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove easylift
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove easylift2
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove medium
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove medium_music
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove mediumtunnel1
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove mediumtunnel2
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove mediumtunnel3
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove mediumtunnel4
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove mediumtunnel5
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove mediumlift
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove mediumlift2
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove hard
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove hard_music
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove hardtunnel1
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove hardtunnel2
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove hardtunnel3
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove hardtunnel4
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove hardtunnel5
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove hardlift
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove hardlift2
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove extreme
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove training
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove endless
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove endlesslift
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove endlesstunnel
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run tag @s remove endless_music
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run title @s times 20 80 20
execute as @a[x=0, y=86, z=-16, dx=0, dy=0, dz=0] at @s run effect @s clear
clear @a[tag=!easylift2, tag=!mediumlift2, tag=!hardlift2] brr:fe_spectate