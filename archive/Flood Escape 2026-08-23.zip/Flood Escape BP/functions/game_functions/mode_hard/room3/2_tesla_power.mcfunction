execute as @s[type=brr:flood_room, name=hard_room2_anchor] at @s if score loaded3 hard matches 0 run summon brr:flood_room ^-8 ^-3 ^2 0 0 * hard_room3
execute as @e[type=brr:flood_room, name=hard_room3] at @s if score loaded3 hard matches 0 run kill @e[type=brr:flood_room, name=hard_room2_anchor]
execute as @e[type=brr:flood_room, name=hard_room3] at @s if score loaded3 hard matches 0 run structure load "hard/room3/2_tesla_power:HardRoom3V2" ~-8 ~1 ~-7
execute as @e[type=brr:flood_room, name=hard_room3] at @s if score loaded3 hard matches 0 run scoreboard players add R3B1 hard 0
execute as @e[type=brr:flood_room, name=hard_room3] at @s if score loaded3 hard matches 0 run scoreboard players add R3B2 hard 0
execute as @e[type=brr:flood_room, name=hard_room3] at @s if score loaded3 hard matches 0 run scoreboard players add R3B3 hard 0
execute as @e[type=brr:flood_room, name=hard_room3] at @s if score loaded3 hard matches 0 run scoreboard players add R3B4 hard 0
execute as @e[type=brr:flood_room, name=hard_room3] at @s if score loaded3 hard matches 0 run scoreboard players add r3_end hard 0
execute as @e[type=brr:flood_room, name=hard_room3] at @s if score loaded3 hard matches 0 run setblock ~ ~9 ~ air
execute as @e[type=brr:flood_room, name=hard_room3] at @s if score loaded3 hard matches 0 run summon brr:flood_room ~ ~9 ~ ~ ~ * laser
execute as @e[type=brr:flood_room, name=hard_room3] at @s if score loaded3 hard matches 0 positioned ~ ~9 ~ run tag @e[type=brr:flood_room, name=laser, r=1] add hard
execute as @e[type=brr:flood_room, name=hard_room3] at @s if score loaded3 hard matches 0 run setblock ~ ~13 ~ air
execute as @e[type=brr:flood_room, name=hard_room3] at @s if score loaded3 hard matches 0 run summon brr:flood_room ~ ~13 ~ ~ ~ * laser
execute as @e[type=brr:flood_room, name=hard_room3] at @s if score loaded3 hard matches 0 positioned ~ ~13 ~ run tag @e[type=brr:flood_room, name=laser, r=1] add hard
execute as @e[type=brr:flood_room, name=hard_room3] at @s if score loaded3 hard matches 0 run setblock ~ ~17 ~ air
execute as @e[type=brr:flood_room, name=hard_room3] at @s if score loaded3 hard matches 0 run summon brr:flood_room ~ ~17 ~ ~ ~ * laser
execute as @e[type=brr:flood_room, name=hard_room3] at @s if score loaded3 hard matches 0 positioned ~ ~17 ~ run tag @e[type=brr:flood_room, name=laser, r=1] add hard
execute as @e[type=brr:flood_room, name=laser, tag=hard] at @s if score loaded3 hard matches 0 run scoreboard players set @s laser_visibility 0
execute as @e[type=brr:flood_room, name=laser, tag=hard] at @s if score loaded3 hard matches 0 run scoreboard players set @s laser_spin_speed 0
execute as @e[type=brr:flood_room, name=hard_room3] at @s if score loaded3 hard matches 0 run scoreboard players set loaded3 hard 1
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 1 run scoreboard players set loaded endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run structure load "hard:HardTunnel" ~8 ~2 ~-3 90_degrees
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run structure load "hard/room3:HardRoom3" ~-8 ~1 ~-7
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run structure load "hard/room3/2_tesla_power:HardRoom3V2" ~-8 ~1 ~-7
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players add R3B1 endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players add R3B2 endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players add R3B3 endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players add R3B4 endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players add endless_end endless 0
execute as @e[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run setblock ~ ~9 ~ air
execute as @e[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run summon brr:flood_room ~ ~9 ~ ~ ~ * laser
execute as @e[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 positioned ~ ~9 ~ run tag @e[type=brr:flood_room, name=laser, r=1] add endless
execute as @e[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run setblock ~ ~13 ~ air
execute as @e[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run summon brr:flood_room ~ ~13 ~ ~ ~ * laser
execute as @e[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 positioned ~ ~13 ~ run tag @e[type=brr:flood_room, name=laser, r=1] add endless
execute as @e[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run setblock ~ ~17 ~ air
execute as @e[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run summon brr:flood_room ~ ~17 ~ ~ ~ * laser
execute as @e[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 positioned ~ ~17 ~ run tag @e[type=brr:flood_room, name=laser, r=1] add endless
execute as @e[type=brr:flood_room, name=laser, tag=endless] at @s if score loaded endless matches 0 run scoreboard players set @s laser_visibility 0
execute as @e[type=brr:flood_room, name=laser, tag=endless] at @s if score loaded endless matches 0 run scoreboard players set @s laser_spin_speed 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run tp @a[tag=endless] ^11 ^3 ^-1.5 facing ^9 ^3 ^-1.5
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run tag @a[tag=endless] remove endlesstunnel
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players set loaded endless 1