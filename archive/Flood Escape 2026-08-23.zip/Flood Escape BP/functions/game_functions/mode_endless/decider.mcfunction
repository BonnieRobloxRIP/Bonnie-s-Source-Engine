scoreboard players random difficulty endless 1 3
execute if score difficulty endless matches 1 run scoreboard players random room endless 1 3
execute if score difficulty endless matches 2 run scoreboard players random room endless 1 3
execute if score difficulty endless matches 3 run scoreboard players random room endless 1 3
execute if score difficulty endless matches 1 if score room endless matches 1 run scoreboard players random variant endless 1 4
execute if score difficulty endless matches 1 if score room endless matches 2 run scoreboard players random variant endless 1 4
execute if score difficulty endless matches 1 if score room endless matches 3 run scoreboard players random variant endless 1 4
execute if score difficulty endless matches 2 if score room endless matches 1 run scoreboard players random variant endless 1 3
execute if score difficulty endless matches 2 if score room endless matches 2 run scoreboard players random variant endless 1 3
execute if score difficulty endless matches 2 if score room endless matches 3 run scoreboard players random variant endless 1 3
execute if score difficulty endless matches 3 if score room endless matches 1 run scoreboard players random variant endless 1 2
execute if score difficulty endless matches 3 if score room endless matches 2 run scoreboard players random variant endless 1 2
execute if score difficulty endless matches 3 if score room endless matches 3 run scoreboard players random variant endless 1 2
execute if score difficulty endless matches 1 if score room endless matches 1..3 run scoreboard players set endless_timer_s endless 31
execute if score difficulty endless matches 2 if score room endless matches 1..3 run scoreboard players set endless_timer_s endless 16
execute if score difficulty endless matches 3 if score room endless matches 1..3 run scoreboard players set endless_timer_s endless 11
scoreboard players set endless_timer_ms endless 0
execute if score difficulty endless matches 1 if score room endless matches 1 if score variant endless matches 1 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_easy/room1/1_ruined_bridge
execute if score difficulty endless matches 1 if score room endless matches 1 if score variant endless matches 2 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_easy/room1/2_strange_warehouse
execute if score difficulty endless matches 1 if score room endless matches 1 if score variant endless matches 3 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_easy/room1/3_storage_low
execute if score difficulty endless matches 1 if score room endless matches 1 if score variant endless matches 4 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_easy/room1/4_alternative_way
execute if score difficulty endless matches 1 if score room endless matches 2 if score variant endless matches 1 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_easy/room2/1_jump_up
execute if score difficulty endless matches 1 if score room endless matches 2 if score variant endless matches 2 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_easy/room2/2_limited_time
execute if score difficulty endless matches 1 if score room endless matches 2 if score variant endless matches 3 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_easy/room2/3_mazed_warehouse
execute if score difficulty endless matches 1 if score room endless matches 2 if score variant endless matches 4 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_easy/room2/4_extra_buttons
execute if score difficulty endless matches 1 if score room endless matches 3 if score variant endless matches 1 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_easy/room3/1_the_wall
execute if score difficulty endless matches 1 if score room endless matches 3 if score variant endless matches 2 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_easy/room3/2_absurd_pipeline
execute if score difficulty endless matches 1 if score room endless matches 3 if score variant endless matches 3 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_easy/room3/3_power_core
execute if score difficulty endless matches 1 if score room endless matches 3 if score variant endless matches 4 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_easy/room3/4_wooden_highground
execute if score difficulty endless matches 2 if score room endless matches 1 if score variant endless matches 1 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_medium/room1/1_stone_platforms
execute if score difficulty endless matches 2 if score room endless matches 1 if score variant endless matches 2 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_medium/room1/2_plenty_of_space
execute if score difficulty endless matches 2 if score room endless matches 1 if score variant endless matches 3 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_medium/room1/3_dusty_bridges
execute if score difficulty endless matches 2 if score room endless matches 2 if score variant endless matches 1 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_medium/room2/1_confusing_lines
execute if score difficulty endless matches 2 if score room endless matches 2 if score variant endless matches 2 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_medium/room2/2_advanced_tech
execute if score difficulty endless matches 2 if score room endless matches 2 if score variant endless matches 3 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_medium/room2/3_mechanical_bridges
execute if score difficulty endless matches 2 if score room endless matches 3 if score variant endless matches 1 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_medium/room3/1_labyrinth
execute if score difficulty endless matches 2 if score room endless matches 3 if score variant endless matches 2 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_medium/room3/2_better_chances
execute if score difficulty endless matches 2 if score room endless matches 3 if score variant endless matches 3 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_medium/room3/3_electric_tower
execute if score difficulty endless matches 3 if score room endless matches 1 if score variant endless matches 1 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_hard/room1/1_trapped
execute if score difficulty endless matches 3 if score room endless matches 1 if score variant endless matches 2 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_hard/room1/2_interesting_paths
execute if score difficulty endless matches 3 if score room endless matches 2 if score variant endless matches 1 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_hard/room2/1_ventilation_failure
execute if score difficulty endless matches 3 if score room endless matches 2 if score variant endless matches 2 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_hard/room2/2_broken_system
execute if score difficulty endless matches 3 if score room endless matches 3 if score variant endless matches 1 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_hard/room3/1_master_lift
execute if score difficulty endless matches 3 if score room endless matches 3 if score variant endless matches 2 as @e[type=brr:flood_room, name=endless] at @s run function game_functions/mode_hard/room3/2_tesla_power