execute as @s[type=brr:flood_room, name=easy_room1_anchor] at @s if score loaded2 easy matches 0 run summon brr:flood_room ^3 ^-4 ^8 0 0 * easy_room2
execute as @e[type=brr:flood_room, name=easy_room2] at @s if score loaded2 easy matches 0 run kill @e[type=brr:flood_room, name=easy_room1_anchor]
execute as @e[type=brr:flood_room, name=easy_room2] at @s if score loaded2 easy matches 0 run structure load "easy/room2/1_jump_up:EasyRoom2V1" ~-7 ~1 ~-7
execute as @e[type=brr:flood_room, name=easy_room2] at @s if score loaded2 easy matches 0 run summon brr:flood_room ^3 ^19 ^14 0 0 * easy_room2_anchor
execute as @e[type=brr:flood_room, name=easy_room2] at @s if score loaded2 easy matches 0 run scoreboard players add R2B1 easy 0
execute as @e[type=brr:flood_room, name=easy_room2] at @s if score loaded2 easy matches 0 run scoreboard players add R2B2 easy 0
execute as @e[type=brr:flood_room, name=easy_room2] at @s if score loaded2 easy matches 0 run scoreboard players add R2B3 easy 0
execute as @e[type=brr:flood_room, name=easy_room2] at @s if score loaded2 easy matches 0 run scoreboard players add R2B4 easy 0
execute as @e[type=brr:flood_room, name=easy_room2] at @s if score loaded2 easy matches 0 run scoreboard players add R2B5 easy 0
execute as @e[type=brr:flood_room, name=easy_room2] at @s if score loaded2 easy matches 0 run scoreboard players add R2B6 easy 0
execute as @e[type=brr:flood_room, name=easy_room2] at @s if score loaded2 easy matches 0 run scoreboard players add r2_end easy 0
execute as @e[type=brr:flood_room, name=easy_room2] at @s if score loaded2 easy matches 0 run scoreboard players set loaded2 easy 1
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 1 run scoreboard players set loaded endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run structure load "easy:EasyTunnel" ~-4 ~3 ~-14
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run structure load "easy/room2:EasyRoom2" ~-7 ~1 ~-7
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run structure load "easy/room2/1_jump_up:EasyRoom2V1" ~-7 ~1 ~-7
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players add R2B1 endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players add R2B2 endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players add R2B3 endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players add R2B4 endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players add R2B5 endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players add R2B6 endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players add endless_end endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run tp @a[tag=endless] ^-2.5 ^4 ^-11 facing ^-2.5 ^4 ^-8
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run tag @a[tag=endless] remove endlesstunnel
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players set loaded endless 1