execute as @s[type=brr:flood_room, name=medium_room2_anchor] at @s if score loaded3 medium matches 0 run summon brr:flood_room ^-3 ^-2 ^-8 0 0 * medium_room3
execute as @e[type=brr:flood_room, name=medium_room3] at @s if score loaded3 medium matches 0 run kill @e[type=brr:flood_room, name=medium_room2_anchor]
execute as @e[type=brr:flood_room, name=medium_room3] at @s if score loaded3 medium matches 0 run structure load "medium/room3/3_electric_tower:MediumRoom3V3" ~-16 ~1 ~-7
execute as @e[type=brr:flood_room, name=medium_room3] at @s if score loaded3 medium matches 0 run scoreboard players add R3B1 medium 0
execute as @e[type=brr:flood_room, name=medium_room3] at @s if score loaded3 medium matches 0 run scoreboard players add R3B2 medium 0
execute as @e[type=brr:flood_room, name=medium_room3] at @s if score loaded3 medium matches 0 run scoreboard players add R3B3 medium 0
execute as @e[type=brr:flood_room, name=medium_room3] at @s if score loaded3 medium matches 0 run scoreboard players add r3_end medium 0
execute as @e[type=brr:flood_room, name=medium_room3] at @s if score loaded3 medium matches 0 run scoreboard players set loaded3 medium 1
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 1 run scoreboard players set loaded endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run structure load "medium:MediumTunnel" ~2 ~1 ~8
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run structure load "medium/room3:MediumRoom3" ~-16 ~1 ~-7
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run structure load "medium/room3/3_electric_tower:MediumRoom3V3" ~-16 ~1 ~-7
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players add R3B1 endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players add R3B2 endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players add R3B3 endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players add endless_end endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run tp @a[tag=endless] ^3.5 ^2 ^11 facing ^3.5 ^2 ^8
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run tag @a[tag=endless] remove endlesstunnel
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players set loaded endless 1