execute as @s[type=brr:flood_room, name=medium_room1_anchor] at @s if score loaded2 medium matches 0 run summon brr:flood_room ^-1 ^-2 ^-8 0 0 * medium_room2
execute as @e[type=brr:flood_room, name=medium_room2] at @s if score loaded2 medium matches 0 run kill @e[type=brr:flood_room, name=medium_room1_anchor]
execute as @e[type=brr:flood_room, name=medium_room2] at @s if score loaded2 medium matches 0 run structure load "medium/room2/3_mechanical_bridges:MediumRoom2V3" ~-7 ~1 ~-14
execute as @e[type=brr:flood_room, name=medium_room2] at @s if score loaded2 medium matches 0 run summon brr:flood_room ^-4 ^19 ^-14 0 0 * medium_room2_anchor
execute as @e[type=brr:flood_room, name=medium_room2] at @s if score loaded2 medium matches 0 run scoreboard players add R2B1 medium 0
execute as @e[type=brr:flood_room, name=medium_room2] at @s if score loaded2 medium matches 0 run scoreboard players add R2B2 medium 0
execute as @e[type=brr:flood_room, name=medium_room2] at @s if score loaded2 medium matches 0 run scoreboard players add r2_end medium 0
execute as @e[type=brr:flood_room, name=medium_room2] at @s if score loaded2 medium matches 0 run scoreboard players set loaded2 medium 1
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 1 run scoreboard players set loaded endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run structure load "medium:MediumTunnel" ~ ~1 ~8
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run structure load "medium/room2:MediumRoom2" ~-7 ~1 ~-14
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run structure load "medium/room2/3_mechanical_bridges:MediumRoom2V3" ~-7 ~1 ~-14
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players add R2B1 endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players add R2B2 endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players add endless_end endless 0
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run tp @a[tag=endless] ^1.5 ^2 ^11 facing ^1.5 ^2 ^7
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run tag @a[tag=endless] remove endlesstunnel
execute as @s[type=brr:flood_room, name=endless] at @s if score loaded endless matches 0 run scoreboard players set loaded endless 1